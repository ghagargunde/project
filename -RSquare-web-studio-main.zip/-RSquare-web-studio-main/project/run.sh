 #
 # Copyright © Samyak. - All Rights Reserved
 # Unauthorized copying of this file, via any medium is strictly prohibited
 # Proprietary and confidential
 # Written by Samyak Ghagargunde <Samyakghagargunde66@gmail.com>, November 2022
 #


gnome-terminal --window-with-profile=multi --command="bash -c 'cd ImageBack && npm run dev'"
gnome-terminal --window-with-profile=multi --command="bash -c 'cd frontend && npm start'"

return
